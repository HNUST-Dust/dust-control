import importlib.util
import unittest
from pathlib import Path

root=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('igc_rx_decode',root/'tools/experiments/igc_rx_timestamp/decode.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def calibration(mono, offset, span=20):
    return {'best':dict(before_ns=mono-span//2,after_ns=mono+span//2,phc_ns=mono-offset)}

def binary(mode=2, flags=7, overflow=0, unstamped=0, bad=0, duplicate=False, hw=None):
    # Realistic PHC epoch vs monotonic: precision must survive cancellation.
    epoch=1_790_000_000_000_000_000
    hw=epoch+30000 if hw is None else hw
    r=m.RECORD.pack(0,hw,32000,33000,524,0,42,3,496,flags,12,255,0,0)
    if duplicate:r+=m.RECORD.pack(1,hw,32000,33100,524,0,42,3,496,flags,12,255,0,0)
    return m.HEADER.pack(0x31525844,1,64,262144,2 if duplicate else 1,
                         overflow,unstamped,bad,mode,0,0)+r

class DecodeContracts(unittest.TestCase):
    def setUp(self):
        self.epoch=1_790_000_000_000_000_000
        self.pre=calibration(10000,-self.epoch+1000)
        self.post=calibration(100000,-self.epoch+1000)
        self.samples=[dict(sample='0',receive_enter_ns='32000',rx_ns='34000',publication='42',batch='3')]
    def test_exact_large_epoch_and_join(self):
        d=m.decode(binary(),self.pre,self.post,self.samples)
        self.assertEqual(d['joined'][0]['nic_to_poll_us'],1)
        self.assertEqual(d['joined'][0]['hardware_to_app_us'],3)
        self.assertEqual(d['clock']['pre_uncertainty_ns'],10)
    def test_arrival_during_poll_is_signed(self):
        d=m.decode(binary(hw=self.epoch+31500),self.pre,self.post)
        self.assertEqual(d['metrics']['nic_to_poll_us']['min'],-.5)
    def test_software_mode_no_hardware_claim(self):
        d=m.decode(binary(mode=1,flags=6,unstamped=1),samples=self.samples)
        self.assertIsNone(d['joined'][0]['hardware_to_app_us'])
    def test_overflow_missing_and_malformed_rejected(self):
        for raw in [binary(overflow=1),binary(unstamped=1),binary(bad=1),
                    binary(flags=6),binary()[:-1],binary()[:20]]:
            with self.assertRaises(ValueError):m.decode(raw,self.pre,self.post)
        with self.assertRaises(ValueError):m.decode(binary())
    def test_join_ambiguity_rejected(self):
        with self.assertRaises(ValueError):m.decode(binary(duplicate=True),self.pre,self.post,self.samples)
    def test_clock_step_and_reversed_bracket_rejected(self):
        post=calibration(100000,-self.epoch+1000000)
        with self.assertRaises(ValueError):m.decode(binary(),self.pre,post)
        with self.assertRaises(ValueError):m.decode(binary(),self.post,self.pre)
        c={'best':dict(before_ns=100,after_ns=99,phc_ns=1)}
        with self.assertRaises(ValueError):m.clock_point(c)

if __name__=='__main__':unittest.main()
