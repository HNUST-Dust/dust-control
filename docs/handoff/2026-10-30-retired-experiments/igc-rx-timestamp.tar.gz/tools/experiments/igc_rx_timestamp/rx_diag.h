/* SPDX-License-Identifier: GPL-2.0 */
/* Diagnostic only: included by igc_main in the isolated build. */
#include <linux/debugfs.h>
#include <linux/vmalloc.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/ktime.h>
#include <asm/unaligned.h>

#define RX_DIAG_CAPACITY 262144U
static unsigned int ecat_rx_diag;
static char *ecat_diag_bdf = "0000:58:00.0";
module_param(ecat_diag_bdf, charp, 0444);
static bool rx_diag_target(struct igc_adapter *adapter)
{
 return ecat_rx_diag && !strcmp(pci_name(adapter->pdev), ecat_diag_bdf);
}
module_param(ecat_rx_diag, uint, 0444);
MODULE_PARM_DESC(ecat_rx_diag, "0=off,1=software records,2=hardware RX timestamps; isolated lab only");
struct rx_diag_record {
 u64 seq, hw_ns, poll_ns, record_ns;
 u32 length, address, publication, accepted;
 u16 data_length, flags;
 u8 command, index;
 u16 reserved;
 u64 reserved2;
};
struct rx_diag_header {
 u32 magic, version, record_size, capacity, count, overflow;
 u64 unstamped, bad_frames, reserved[3];
};
static struct rx_diag_record *rx_diag_records;
static struct rx_diag_header rx_diag_header;
static DEFINE_SPINLOCK(rx_diag_lock);
static DEFINE_MUTEX(rx_diag_control_lock);
static bool rx_diag_armed;
static unsigned int rx_diag_readers;
static struct dentry *rx_diag_dir;
/* ec_poll is serialized by the existing IgH master lock. */
static u64 rx_diag_poll_ns;
extern int igc_ecat_diag_timestamp(struct igc_adapter *adapter);

static int rx_diag_open(struct inode *inode, struct file *file)
{
 int ret = 0;
 mutex_lock(&rx_diag_control_lock);
 if (READ_ONCE(rx_diag_armed)) ret = -EBUSY;
 else ++rx_diag_readers;
 mutex_unlock(&rx_diag_control_lock);
 return ret;
}
static int rx_diag_release(struct inode *inode, struct file *file)
{
 mutex_lock(&rx_diag_control_lock);
 --rx_diag_readers;
 mutex_unlock(&rx_diag_control_lock);
 return 0;
}
static ssize_t rx_diag_read(struct file *file, char __user *buf, size_t len, loff_t *pos)
{
 size_t total = sizeof(rx_diag_header) + rx_diag_header.count * sizeof(*rx_diag_records);
 ssize_t ret;
 if (*pos < 0) return -EINVAL;
 if (*pos >= total) return 0;
 if (*pos < sizeof(rx_diag_header))
  return simple_read_from_buffer(buf, len, pos, &rx_diag_header, sizeof(rx_diag_header));
 /* Arm is rejected while a reader is open, so records remain immutable. */
 {
  loff_t offset = *pos - sizeof(rx_diag_header);
  ret = simple_read_from_buffer(buf, len, &offset, rx_diag_records,
         total - sizeof(rx_diag_header));
  if (ret > 0) *pos += ret;
 }
 return ret;
}
static ssize_t rx_diag_control(struct file *file, const char __user *buf, size_t len, loff_t *pos)
{
 char cmd[16]; unsigned long key; int ret = 0;
 if (!len || len >= sizeof(cmd)) return -EINVAL;
 if (copy_from_user(cmd, buf, len)) return -EFAULT;
 cmd[len] = 0;
 mutex_lock(&rx_diag_control_lock);
 if (sysfs_streq(cmd, "arm")) {
  if (rx_diag_readers) { ret = -EBUSY; goto out; }
  spin_lock_irqsave(&rx_diag_lock, key);
  rx_diag_armed = false;
  memset(&rx_diag_header, 0, sizeof(rx_diag_header));
  rx_diag_header.magic = 0x31525844; /* DXR1, little endian x86 */
  rx_diag_header.version = 1;
  rx_diag_header.record_size = sizeof(*rx_diag_records);
  rx_diag_header.capacity = RX_DIAG_CAPACITY;
  rx_diag_header.reserved[0] = ecat_rx_diag;
  rx_diag_armed = true;
  spin_unlock_irqrestore(&rx_diag_lock, key);
 } else if (sysfs_streq(cmd, "stop")) {
  spin_lock_irqsave(&rx_diag_lock, key);
  rx_diag_armed = false;
  spin_unlock_irqrestore(&rx_diag_lock, key);
 } else ret = -EINVAL;
 out: mutex_unlock(&rx_diag_control_lock);
 return ret ? ret : len;
}
static const struct file_operations rx_diag_data_ops = {
 .owner = THIS_MODULE, .open = rx_diag_open, .release = rx_diag_release,
 .read = rx_diag_read, .llseek = no_llseek,
};
static const struct file_operations rx_diag_control_ops = {
 .owner = THIS_MODULE, .write = rx_diag_control, .llseek = no_llseek,
};
static int rx_diag_init(void)
{
 struct dentry *d;
 BUILD_BUG_ON(sizeof(struct rx_diag_header) != 64);
 BUILD_BUG_ON(sizeof(struct rx_diag_record) != 64);
 if (ecat_rx_diag > 2) return -EINVAL;
 if (!ecat_rx_diag) return 0;
 rx_diag_records = vzalloc(array_size(RX_DIAG_CAPACITY, sizeof(*rx_diag_records)));
 if (!rx_diag_records) return -ENOMEM;
 rx_diag_dir = debugfs_create_dir("ec_igc_rx_diag", NULL);
 if (IS_ERR(rx_diag_dir)) goto fail;
 d = debugfs_create_file("data", 0400, rx_diag_dir, NULL, &rx_diag_data_ops);
 if (IS_ERR_OR_NULL(d)) goto fail;
 d = debugfs_create_file("control", 0200, rx_diag_dir, NULL, &rx_diag_control_ops);
 if (IS_ERR_OR_NULL(d)) goto fail;
 return 0;
 fail:
 if (!IS_ERR_OR_NULL(rx_diag_dir)) debugfs_remove_recursive(rx_diag_dir);
 vfree(rx_diag_records); rx_diag_records = NULL;
 return -ENODEV;
}
static void rx_diag_exit(void)
{
 debugfs_remove_recursive(rx_diag_dir);
 vfree(rx_diag_records);
}
static void rx_diag_record(const u8 *frame, unsigned int length, bool stamped, u64 hw_ns)
{
 struct rx_diag_record r = {0}; unsigned long key;
 if (!READ_ONCE(rx_diag_armed)) return;
 r.hw_ns = hw_ns; r.poll_ns = rx_diag_poll_ns;
 r.record_ns = ktime_get_ns(); r.length = length;
 if (stamped) r.flags |= 1;
 if (length >= 26 && get_unaligned_be16(frame + 12) == 0x88a4) {
  unsigned int ec_len = get_unaligned_le16(frame + 14) & 0x7ff;
  r.command = frame[16]; r.index = frame[17];
  r.address = get_unaligned_le32(frame + 18);
  r.data_length = get_unaligned_le16(frame + 22) & 0x7ff;
  if (ec_len >= 12 && length >= ec_len + 16 && ec_len >= r.data_length + 12) {
   r.flags |= 2;
   /* Optional identity for this bench's single LRW Rx96/Tx400 layout.
    * Absence is explicit; never guess when datagrams are split/reordered. */
   if (r.command == 12 && !r.address && r.data_length >= 148 &&
       get_unaligned_le32(frame + 26 + 96) == 0x31435444) {
    r.publication = get_unaligned_le32(frame + 26 + 96 + 24);
    r.accepted = get_unaligned_le32(frame + 26 + 96 + 48);
    r.flags |= 4;
   }
  }
 }
 spin_lock_irqsave(&rx_diag_lock, key);
 if (rx_diag_armed) {
  if (!stamped) ++rx_diag_header.unstamped;
  if (!(r.flags & 2)) ++rx_diag_header.bad_frames;
  if (rx_diag_header.count < RX_DIAG_CAPACITY) {
   r.seq = rx_diag_header.count;
   rx_diag_records[rx_diag_header.count++] = r;
  } else if (rx_diag_header.overflow != U32_MAX) ++rx_diag_header.overflow;
 }
 spin_unlock_irqrestore(&rx_diag_lock, key);
}
