#!/usr/bin/env python3
"""Prepare isolated IgH stable-1.7 igc5.15 sources; never install/load modules."""
from pathlib import Path
import argparse
import shutil

def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError(f'Unrecognized driver source anchor: {old[:80]!r}')
    return text.replace(old,new,1)

def prepare(tree):
    d=tree/'devices/igc'
    p=d/'igc_main-5.15-ethercat.c';s=p.read_text()
    s=replace_once(s,'#define DRV_SUMMARY', '#include "dust_rx_diag.h"\n\n#define DRV_SUMMARY')
    # Guard prefix length before subtracting it or handing data to XDP/IgH.
    start=s.index('static int igc_clean_rx_irq(')
    end=s.index('static int igc_clean_rx_irq_zc(',start)
    part=s[start:end]
    guard="""		if (!size)
			break;"""
    guarded=guard+"""
		if (get_ecdev(adapter) &&
		    unlikely(igc_test_staterr(rx_desc, IGC_RXDADV_STAT_TSIP) &&
			     size < IGC_TS_HDR_LEN)) {
			/* Corrupt descriptor: stop this poll, never underflow a length. */
			if (rx_diag_target(adapter))
				rx_diag_record(NULL, 0, false, 0);
			break;
		}"""
    part=replace_once(part,guard,guarded)
    s=s[:start]+part+s[end:]
    old='''			unsigned char *va = page_address(rx_buffer->page) + rx_buffer->page_offset;
			unsigned int size = le16_to_cpu(rx_desc->wb.upper.length);
			ecdev_receive(get_ecdev(adapter), va, size);'''
    new='''			/* Timestamp prefix has already been parsed above. Use the same
			 * offset/length as the normal netdev path, not the raw descriptor. */
			unsigned char *va = (unsigned char *)pktbuf + pkt_offset;
			if (rx_diag_target(adapter))
				rx_diag_record(va, size, pkt_offset == IGC_TS_HDR_LEN,
					       ktime_to_ns(timestamp));
			ecdev_receive(get_ecdev(adapter), va, size);'''
    s=replace_once(s,old,new)
    s=replace_once(s,'\tint budget = 64;\n','\tint budget = 64;\n\n\tif (rx_diag_target(adapter))\n\t\trx_diag_poll_ns = ktime_get_ns();\n')
    old='\tigc_configure(adapter);\n\n\terr = igc_request_irq(adapter);'
    new='''	igc_configure(adapter);

	if (ecat_rx_diag == 2 && get_ecdev(adapter) && rx_diag_target(adapter)) {
		err = igc_ecat_diag_timestamp(adapter);
		if (err)
			goto err_req_irq;
	}

	err = igc_request_irq(adapter);'''
    s=replace_once(s,old,new)
    s=replace_once(s,'\tret = pci_register_driver(&igc_driver);\n\treturn ret;', '''	ret = rx_diag_init();
	if (ret)
		return ret;
	ret = pci_register_driver(&igc_driver);
	if (ret)
		rx_diag_exit();
	return ret;''')
    s=replace_once(s,'\tpci_unregister_driver(&igc_driver);','\tpci_unregister_driver(&igc_driver);\n\trx_diag_exit();')
    p.write_text(s)
    p=d/'igc_ptp-5.15-ethercat.c';s=p.read_text()
    marker='static void igc_ptp_tx_timeout(struct igc_adapter *adapter)'
    helper='''/* Isolated lab helper: RX only; no TX timestamp requests. */
int igc_ecat_diag_timestamp(struct igc_adapter *adapter)
{
	struct hwtstamp_config config = {
		.flags = 0, .tx_type = HWTSTAMP_TX_OFF,
		.rx_filter = HWTSTAMP_FILTER_ALL,
	};
	int ret;
	if (!adapter->ptp_clock)
		return -ENODEV;
	ret = igc_ptp_set_timestamp_mode(adapter, &config);
	if (!ret)
		adapter->tstamp_config = config;
	return ret;
}

'''
    s=replace_once(s,marker,helper+marker);p.write_text(s)
    p=d/'igc-5.15-ethercat.h';s=p.read_text()
    # At end of header, after adapter declaration.
    pos=s.rfind('#endif');assert pos>=0
    s=s[:pos]+'int igc_ecat_diag_timestamp(struct igc_adapter *adapter);\n\n'+s[pos:];p.write_text(s)
    shutil.copy(Path(__file__).with_name('rx_diag.h'),d/'dust_rx_diag.h')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source_tree',type=Path)
    a=p.parse_args();prepare(a.source_tree)
