#!/usr/bin/env python3
"""Read-only PHC-to-CLOCK_MONOTONIC bracket samples; never adjust either clock."""
import argparse
import json
import os
import time
from pathlib import Path

def calibrate(device, count=200):
    fd=os.open(device,os.O_RDONLY)
    try:
        clock_id=((~fd)<<3)|3
        samples=[]
        for _ in range(count):
            before=time.clock_gettime_ns(time.CLOCK_MONOTONIC)
            phc=time.clock_gettime_ns(clock_id)
            after=time.clock_gettime_ns(time.CLOCK_MONOTONIC)
            samples.append(dict(before_ns=before,phc_ns=phc,after_ns=after))
        best=min(samples,key=lambda s:s['after_ns']-s['before_ns'])
        return dict(version=1,device=device,samples=samples,best=best,
                    limits='Read bracket uncertainty; linear drift between pre/post is an assumption, not proof of no clock step.')
    finally:
        os.close(fd)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('device');p.add_argument('output',type=Path);a=p.parse_args()
    a.output.write_text(json.dumps(calibrate(a.device),indent=2)+'\n')
