#!/usr/bin/env python3
"""Decode bounded native igc diagnostic records and optionally join RTT samples."""
import argparse
from fractions import Fraction
import bisect
import csv
import json
import statistics
import struct
from pathlib import Path
HEADER=struct.Struct('<6I5Q')
RECORD=struct.Struct('<4Q4I2H2BHQ')

def stats(v):
    if not v:return None
    s=sorted(v)
    return dict(count=len(s),min=min(s),mean=statistics.mean(s),p50=s[(len(s)-1)//2],
                p95=s[int((len(s)-1)*.95)],max=max(s))

def clock_point(c):
    s=c['best'];before,after,phc=(s[k] for k in ['before_ns','after_ns','phc_ns'])
    if before>after:raise ValueError('Clock read bracket is reversed')
    mid=Fraction(before+after,2)
    return mid, mid-phc, Fraction(after-before,2)

def decode(raw, pre=None, post=None, samples=None):
    if len(raw)<HEADER.size:raise ValueError('Truncated header')
    h=HEADER.unpack_from(raw)
    magic,version,size,capacity,count,overflow,unstamped,bad,mode,_,_=h
    if (magic,version,size)!=(0x31525844,1,64) or mode not in (1,2):
        raise ValueError('Unknown diagnostic format or mode')
    if not count or count>capacity or len(raw)!=64+count*64:raise ValueError('Invalid count/length')
    if overflow or bad:raise ValueError(f'Overflow={overflow}, bad frames={bad}; reject timing inference')
    if mode==2 and unstamped:raise ValueError('Hardware mode contains unstamped frames')
    if mode==2 and (pre is None or post is None):raise ValueError('PHC calibration required')
    points=None
    if mode==2:
        a,b=clock_point(pre),clock_point(post)
        if a[0]>=b[0]:raise ValueError('Pre/post calibration time order invalid')
        points=(a,b)
    metrics={'poll_to_record_us':[],'nic_to_poll_us':[]}
    records=[]
    for i in range(count):
        r=RECORD.unpack_from(raw,64+i*64)
        seq,hw,poll,record,length,address,pub,batch,data_len,flags,cmd,index,_,_=r
        if seq!=i or record<poll or not flags&2:raise ValueError('Invalid record order/frame')
        if records and record<records[-1]['record_ns']:raise ValueError('Nonmonotonic records')
        hw_mono=None
        if mode==2:
            if not flags&1 or not hw:raise ValueError('Missing hardware timestamp')
            a,b=points
            # Solve mono = phc + linearly varying offset(mono).
            slope=(b[1]-a[1])/(b[0]-a[0])
            if abs(slope)>0.001:raise ValueError('PHC step/excessive drift suspected')
            hw_mono=(hw+a[1]-slope*a[0])/(1-slope)
            if hw_mono<a[0]-1e9 or hw_mono>b[0]+1e9:
                raise ValueError('Hardware time outside calibration interval')
            if hw_mono>record+max(a[2],b[2])+1000:
                raise ValueError('Hardware receive after software record; clock mapping inconsistent')
            metrics['nic_to_poll_us'].append(float((poll-hw_mono)/1000))
        metrics['poll_to_record_us'].append((record-poll)/1000)
        records.append(dict(record_ns=record,poll_ns=poll,hw_mono_ns=hw_mono,
            publication=pub,batch=batch,identity_valid=bool(flags&4),index=index,command=cmd))
    joined=[]
    if samples is not None:
        times=[r['record_ns'] for r in records]
        for sample in samples:
            begin,end=int(sample['receive_enter_ns']),int(sample['rx_ns'])
            lo,hi=bisect.bisect_left(times,begin),bisect.bisect_right(times,end)
            candidates=[r for r in records[lo:hi] if r['identity_valid'] and
                r['publication']==int(sample['publication']) and r['batch']==int(sample['batch'])]
            if len(candidates)!=1:raise ValueError(f'RTT sample {sample["sample"]}: {len(candidates)} unique matches')
            r=candidates[0]
            joined.append(dict(sample=int(sample['sample']),publication=r['publication'],
                nic_to_poll_us=None if r['hw_mono_ns'] is None else float((r['poll_ns']-r['hw_mono_ns'])/1000),
                hardware_to_app_us=None if r['hw_mono_ns'] is None else float((end-r['hw_mono_ns'])/1000),
                record_to_app_us=(end-r['record_ns'])/1000))
    result=dict(mode=mode,records=count,overflow=overflow,unstamped=unstamped,
        metrics={k:stats(v) for k,v in metrics.items()},joined=joined,
        limits='Signed NIC-to-poll includes arrivals during the poll (negative values). Record boundary precedes ring write/ecdev delivery. PHC mapping assumes no step and linear drift; no claim about CAN or ESC commit time.')
    if points:
        a,b=points
        result['clock']=dict(pre_uncertainty_ns=float(a[2]),post_uncertainty_ns=float(b[2]),
                            offset_change_ns=float(b[1]-a[1]))
    if joined:
        result['response_metrics']={k:stats([r[k] for r in joined if r[k] is not None])
            for k in ['nic_to_poll_us','hardware_to_app_us','record_to_app_us']}
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('binary',type=Path)
    p.add_argument('--pre',type=Path);p.add_argument('--post',type=Path)
    p.add_argument('--samples',type=Path);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    result=decode(a.binary.read_bytes(),json.loads(a.pre.read_text()) if a.pre else None,
        json.loads(a.post.read_text()) if a.post else None,
        list(csv.DictReader(a.samples.open())) if a.samples else None)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='joined'},indent=2))
