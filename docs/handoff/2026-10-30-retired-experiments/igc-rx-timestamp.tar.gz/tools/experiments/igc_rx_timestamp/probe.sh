#!/usr/bin/env bash
# Temporary driver-only diagnostic. Never overwrite /lib/modules or master.
set -euo pipefail
[[ $EUID == 0 ]] || { echo 'Run with sudo'; exit 2; }
mode=${1:-0}
[[ $mode =~ ^[012]$ ]] || exit 2
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
bench=$(cd -- "$root/../.." && pwd)
# Deployed layout is dust-ecat-bench/rx-diag/experiment/probe.sh.
[[ -x $bench/dust_ethercat_dm_rtt && -f $bench/ethercat_rtt_aspm_probe.sh ]] || exit 2
tag=${2:-master-rx-off-01}
[[ $tag =~ ^[a-zA-Z0-9_-]+$ ]] || exit 2
out="$bench/rx-diag/results/$tag"
[[ ! -e $out && ! -e $bench/dm-rtt-125us-$tag.log && ! -e $bench/dm-rtt-125us-$tag.csv ]] || { echo "Result tag already exists: $tag"; exit 2; }
[[ $(uname -r) == 5.15.0-1114-realtime ]] || exit 2
pci=0000:58:00.0
[[ $(basename "$(readlink "/sys/bus/pci/devices/$pci/driver")") == ec_igc ]] || exit 2
systemctl is-active --quiet ethercat || { echo "Original EtherCAT service must be active"; exit 2; }
master_info=$(ethercat master)
[[ $master_info == *'Active: no'* ]] || { echo 'Master is active; leave it unchanged'; exit 2; }
if pgrep -f '^(/[^ ]*/)?dust_ethercat_dm_rtt(_[[:alnum:]_]+)?([[:space:]]|$)' >/dev/null; then
 echo 'Benchmark still running'; exit 2
fi
# Compare candidate and original binaries to the reviewed manifest before mutation.
python3 - "$root/manifest.json" "$root/ec_igc.ko" <<'PY'
import hashlib,json,subprocess,sys
from pathlib import Path
m=json.loads(Path(sys.argv[1]).read_text())
for key,path in [('candidate',sys.argv[2]),('original',subprocess.check_output(['modinfo','-n','ec_igc'],text=True).strip()),('master',subprocess.check_output(['modinfo','-n','ec_master'],text=True).strip())]:
 if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=m[key]:
  raise SystemExit('Module hash differs from reviewed manifest: '+key)
PY
main_devices=$(cat /sys/module/ec_master/parameters/main_devices)
run_on_cpu=$(cat /sys/module/ec_master/parameters/run_on_cpu)
sii_caching=$(cat /sys/module/ec_master/parameters/sii_caching)
[[ $main_devices == 54:b2:03:9e:f2:fa ]] || exit 2
mkdir -p "$out"
exec > >(tee "$out/driver-probe.log") 2>&1
echo "mode=$mode tag=$tag; firmware gateway must have been reset since previous Stop"
cp "$root/manifest.json" "$out/manifest.json"
printf '%s\n' "$master_info" > "$out/master-before.txt"
changed=0
restore() {
 result=$?
 trap - EXIT
 [[ -w /sys/kernel/debug/ec_igc_rx_diag/control ]] && echo stop > /sys/kernel/debug/ec_igc_rx_diag/control || true
 if [[ $changed == 1 ]]; then
  if ethercat master 2>/dev/null | grep -q 'Active: yes'; then
   echo 'Master remains active: no forced driver unload. Stop the application before restoring.'
   exit 1
  fi
  if ! modprobe -r ec_igc; then
   echo 'Could not unload diagnostic module; no force used.'
   exit 1
  fi
  if ! systemctl start ethercat; then
   echo 'Original service restart failed; original files remain unchanged.'
   exit 1
  fi
  echo 'Original EtherCAT service/driver restored'
  ethercat master > "$out/master-restored.txt" || result=1
 fi
 exit "$result"
}
trap restore EXIT
changed=1
systemctl stop ethercat
# ethercatctl stop reloads the standard igc driver. Unbind only the dedicated
# PCI function; do not unload a driver that could serve unrelated interfaces.
if [[ -L /sys/bus/pci/devices/$pci/driver ]]; then
 driver=$(basename "$(readlink "/sys/bus/pci/devices/$pci/driver")")
 [[ $driver == igc ]] || { echo "Unexpected driver after stop: $driver"; exit 1; }
 echo "$pci" > /sys/bus/pci/drivers/igc/unbind
fi
modprobe ec_master main_devices="$main_devices" run_on_cpu="$run_on_cpu" sii_caching="$sii_caching"
insmod "$root/ec_igc.ko" ecat_rx_diag="$mode" ecat_diag_bdf="$pci"
[[ $(cat /sys/module/ec_igc/parameters/ecat_rx_diag) == "$mode" ]] || exit 1
ready=0
for ((i=0;i<200;i++)); do
 if ethercat slaves | grep -q 'PREOP.*DUST HPM5E31'; then ready=1; break; fi
 sleep 0.1
done
[[ $ready == 1 ]] || { echo 'Slave did not reach PREOP'; exit 1; }
ethercat master > "$out/master-diagnostic.txt"
if [[ $mode != 0 ]]; then
 [[ -w /sys/kernel/debug/ec_igc_rx_diag/control ]] || { echo 'debugfs unavailable'; exit 1; }
 if [[ $mode == 2 ]]; then
  mapfile -t clocks < <(find "/sys/bus/pci/devices/$pci/ptp" -mindepth 1 -maxdepth 1 -type d -printf '%f\n')
  [[ ${#clocks[@]} == 1 ]] || exit 1
  clock_device="/dev/${clocks[0]}"
  python3 "$root/calibrate.py" "$clock_device" "$out/clock-pre.json"
 fi
 echo arm > /sys/kernel/debug/ec_igc_rx_diag/control
fi
unset DUST_RTT_DC_SYNC DUST_RTT_SM_SYNC DUST_RTT_RECEIVE_OFFSET_US DUST_RTT_CYCLE_LOG
status=0
bash "$bench/ethercat_rtt_aspm_probe.sh" 125 2000 "$tag" || status=$?
if [[ $mode != 0 ]]; then
 echo stop > /sys/kernel/debug/ec_igc_rx_diag/control
 [[ $mode == 2 ]] && python3 "$root/calibrate.py" "$clock_device" "$out/clock-post.json"
 cat /sys/kernel/debug/ec_igc_rx_diag/data > "$out/rx.bin"
fi
cp "$bench/dm-rtt-125us-$tag.log" "$bench/dm-rtt-125us-$tag.csv" "$out/"
echo "benchmark_exit=$status"
exit "$status"
