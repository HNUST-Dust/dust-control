from pathlib import Path
import subprocess
r=Path.home()/'dust-ecat-bench/rx-diag'
exports=[line.split() for line in (r/'installed-exports.txt').read_text().splitlines()]
s=(r/'installed-ec-master.symvers')
s.write_text(''.join(f'{crc}\t{name}\tec_master\tEXPORT_SYMBOL\t\n' for crc,name in exports if name.startswith('ecdev_')))
for tree in ['baseline','diagnostic']:
 cmd=['make','-C','/usr/src/linux-headers-5.15.0-1114-realtime',f'M={r/tree/"devices/igc"}',f'KBUILD_EXTRA_SYMBOLS={s}','-j4','modules']
 with (r/tree/'driver-only-build.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 installed=dict(line.split()[1::-1] for line in (r/'installed-import-versions.txt').read_text().splitlines())
 actual=dict(line.split()[1::-1] for line in subprocess.check_output(['modprobe','--dump-modversions',str(r/tree/'devices/igc/ec_igc.ko')],text=True).splitlines())
 errors={n:(installed[n],actual.get(n)) for n in installed if actual.get(n)!=installed[n]}
 if errors:raise RuntimeError(errors)
 print(tree, 'all original imported symbol versions match installed module; new imports resolved against current kernel headers')
