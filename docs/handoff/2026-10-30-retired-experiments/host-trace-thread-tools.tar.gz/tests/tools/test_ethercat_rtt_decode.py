import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('decode', Path(__file__).resolve().parents[2]/'tools/ethercat_rtt_decode.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)

class TraceContracts(unittest.TestCase):
    def fixture(self, valid=65535, seq=9, revision=32):
        header = d.HEADER.pack(0x31525444, 1, 168, 128, 1, 0, 24000000, 40, 7)
        # Hardware counter deliberately crosses 32-bit boundary.
        cycles = [2**32+240*i for i in range(16)]
        record = d.RECORD.pack(revision, valid, 11, 3, 123, 99, seq, 0, 0, *cycles)
        data = header+record+bytes(127*168)
        row = dict(boot='7', session='11', batch='3', publication='100', can_sequence='9', exchange='123')
        for i, s in enumerate(('built', 'encoded', 'output_copied', 'queued', 'tx', 'send_enter', 'send_return', 'receive_enter', 'rx', 'domain_processed', 'image_copied', 'decoded', 'bench_consumed')):
            row[s+'_ns'] = str(100000+i*1000)
        return data, row
    def test_complete_and_retained_publication(self):
        data,row = self.fixture()
        out = d.join(data,[row])[0]
        self.assertEqual(out['trace_status'],'ok')
        self.assertEqual(out['mcu_rx_map_to_esc_end_us'],'130.000')
        self.assertEqual(out['host_built_to_bench_consumed_us'],'12.000')
        row['exchange']='122'
        later=d.join(data,[row])[0]
        self.assertEqual(later['trace_status'],'ok')
        self.assertEqual(later['accepted_exchange_advance'],1)
    def test_v2_queue_stages_and_v1_compatibility(self):
        old,row=self.fixture()
        values=list(d.RECORD.unpack_from(old,d.HEADER.size))
        values[0]=36
        values[1]=(1<<18)-1
        cycles=values[9:]
        values += [cycles[10]+40,cycles[11]-40]
        data=d.HEADER.pack(0x31525444,2,184,128,1,0,24000000,40,7)
        data+=d.RECORD_V2.pack(*values)+bytes(127*184)
        out=d.join(data,[row])[0]
        self.assertEqual(out['trace_status'],'ok')
        self.assertEqual(out['mcu_can_enqueued_to_can_dequeued_us'],'6.667')
        self.assertEqual(out['mcu_can_dequeued_to_capture_us'],'1.667')
    def test_v3_snapshot_stage(self):
        old,row=self.fixture()
        values=list(d.RECORD.unpack_from(old,d.HEADER.size))
        values[0]=38
        values[1]=(1<<19)-1
        cycles=values[9:]
        values += [cycles[10]+40, cycles[11]-40, cycles[11]+120]
        data=d.HEADER.pack(0x31525444,3,192,128,1,0,24000000,40,7)
        data+=d.RECORD_V3.pack(*values)+bytes(127*192)
        out=d.join(data,[row])[0]
        self.assertEqual(out['trace_status'],'ok')
        self.assertEqual(out['mcu_capture_to_can_snapshot_us'],'5.000')
        self.assertEqual(out['mcu_can_snapshot_to_publish_us'],'5.000')

    def test_v4_worker_markers_optional_and_ordered(self):
        old,row=self.fixture()
        values=list(d.RECORD.unpack_from(old,d.HEADER.size))
        cycles=values[9:]
        values[0]=42
        values[1]=(1<<21)-1
        values += [cycles[10]+40, cycles[11]-40, cycles[11]+120,
                   cycles[10]+80, cycles[10]+120]
        header=d.HEADER.pack(0x31525444,4,208,128,1,0,24000000,40,7)
        def decode():
            return d.join(header+d.RECORD_V4.pack(*values)+bytes(127*208),[row])[0]
        self.assertEqual(decode()['trace_status'],'ok')
        self.assertEqual(decode()['mcu_worker_wake_to_worker_locked_us'],'1.667')
        values[1]=(1<<19)-1
        self.assertEqual(decode()['trace_status'],'ok')
        values[1]=(1<<21)-1
        values[-1]=values[-2]-1
        self.assertIn('nonmonotonic_worker_wake_worker_locked',decode()['trace_status'])

    def test_v5_can3_scan_boundary(self):
        old,row=self.fixture()
        values=list(d.RECORD.unpack_from(old,d.HEADER.size))
        cycles=values[9:]
        values[0]=44
        values[1]=(1<<22)-1
        values += [cycles[10]+40, cycles[11]-40, cycles[11]+120,
                   cycles[10]+80, cycles[10]+120, cycles[10]+160]
        header=d.HEADER.pack(0x31525444,5,216,128,1,0,24000000,40,7)
        def decode():
            return d.join(header+d.RECORD_V5.pack(*values)+bytes(127*216),[row])[0]
        self.assertEqual(decode()['trace_status'],'ok')
        self.assertEqual(decode()['mcu_worker_locked_to_can3_scan_us'],'1.667')
        values[1]=(1<<19)-1
        self.assertEqual(decode()['trace_status'],'ok')
        values[1]=(1<<22)-1
        values[-1]=cycles[11]+40
        self.assertIn('nonmonotonic_can3_scan_can_dequeued',decode()['trace_status'])

    def test_v6_snapshot_phases_and_optional_boundaries(self):
        old,row=self.fixture()
        values=list(d.RECORD.unpack_from(old,d.HEADER.size))
        cycles=values[9:]
        values[0]=52
        values[1]=(1<<26)-1
        values += [cycles[10]+40, cycles[11]-40, cycles[11]+120,
                   cycles[10]+80, cycles[10]+120, cycles[10]+160,
                   cycles[11]+20, cycles[11]+40, cycles[11]+60, cycles[11]+80,
                   d.PHASES.index('esc_write'), d.PHASES.index('poll_publish')]
        header=d.HEADER.pack(0x31525444,6,256,128,1,0,24000000,40,7)
        def decode():
            return d.join(header+d.RECORD_V6.pack(*values)+bytes(127*256),[row])[0]
        out=decode()
        self.assertEqual(out['trace_status'],'ok')
        self.assertEqual(out['mcu_capture_phase'],'esc_write')
        self.assertEqual(out['mcu_snapshot_phase'],'poll_publish')
        self.assertEqual(out['mcu_snapshot_begin_to_snapshot_locked_us'],'0.833')
        values[1]=(1<<19)-1
        self.assertEqual(decode()['trace_status'],'ok')
        values[1]=(1<<26)-1
        values[-3]=cycles[11]+140
        self.assertIn('nonmonotonic_snapshot_locked_can_snapshot',decode()['trace_status'])
        values[-1]=99
        with self.assertRaises(ValueError): decode()

    def test_v7_pending_write_and_loop_checkpoints(self):
        old,row=self.fixture()
        values=list(d.RECORD.unpack_from(old,d.HEADER.size))
        cycles=values[9:]
        values[0]=58
        values[1]=(1<<29)-1
        values += [cycles[10]+40, cycles[11]-40, cycles[11]+180,
                   cycles[10]+80, cycles[10]+120, cycles[10]+160,
                   cycles[11]+10, cycles[11]+100, cycles[11]+120, cycles[11]+140,
                   cycles[11]+30, cycles[11]+50, cycles[11]+70,
                   d.PHASES.index('esc_write'), d.PHASES.index('poll_publish')]
        header=d.HEADER.pack(0x31525444,7,280,128,1,0,24000000,40,7)
        def decode():
            return d.join(header+d.RECORD_V7.pack(*values)+bytes(127*280),[row])[0]
        self.assertEqual(decode()['trace_status'],'ok')
        self.assertEqual(decode()['mcu_pending_write_end_to_ssc_return_us'],'0.833')
        values[1]=(1<<19)-1
        self.assertEqual(decode()['trace_status'],'ok')
        values[1]=(1<<29)-1
        values[-3]=cycles[11]+200
        self.assertIn('nonmonotonic_poll_entry_ssc_service',decode()['trace_status'])

    def test_missing_mismatched_and_incomplete(self):
        data,row = self.fixture(valid=2047, seq=10)
        flags = d.join(data,[row])[0]['trace_status']
        self.assertIn('incomplete',flags)
        self.assertIn('can_sequence_mismatch',flags)
        row['boot']='8'
        self.assertIn('missing',d.join(data,[row])[0]['trace_status'])
    def test_reject_partial_dump_and_torn_record(self):
        data,row=self.fixture(revision=1)
        with self.assertRaises(ValueError): d.join(data,[row])
        with self.assertRaises(ValueError): d.read_trace(data[:-1])
    def test_duplicate_host_and_wrong_exchange(self):
        data,row=self.fixture()
        with self.assertRaises(ValueError): d.join(data,[row,row])
        row['exchange']='124'
        self.assertIn('exchange_mismatch',d.join(data,[row])[0]['trace_status'])

if __name__ == '__main__': unittest.main()
