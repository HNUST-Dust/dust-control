/* SPDX-License-Identifier: Apache-2.0 */
#include "esm_diag.h"
#if defined(CONFIG_DUST_ECAT_ESM_DIAG)
#include <zephyr/kernel.h>
#include <zephyr/irq.h>
struct { uint32_t version, count, overflow, reserved;
    struct {uint32_t ms, event, value, aux;} entries[64];
} dust_esm_diag = {1, 0, 0, 0, {{0}}};
void dust_esm_event(uint32_t event, uint32_t value, uint32_t aux) {
    unsigned key=irq_lock();
    if (dust_esm_diag.count < 64) {
        unsigned n=dust_esm_diag.count++;
        dust_esm_diag.entries[n].ms=k_uptime_get_32();
        dust_esm_diag.entries[n].event=event;
        dust_esm_diag.entries[n].value=value;
        dust_esm_diag.entries[n].aux=aux;
    } else ++dust_esm_diag.overflow;
    irq_unlock(key);
}

/* Circular DM-only lifecycle record; no UART or per-cycle log traffic. */
struct { uint32_t version, count, capacity, reserved;
    struct {uint32_t cycles, event, value, aux;} entries[512];
} dust_can_flow_diag = {1,0,512,0,{{0}}};
void dust_can_flow_event(uint32_t event,uint32_t value,uint32_t aux) {
    unsigned key=irq_lock();
    unsigned n=dust_can_flow_diag.count++ % 512;
    dust_can_flow_diag.entries[n].cycles=k_cycle_get_32();
    dust_can_flow_diag.entries[n].event=event;
    dust_can_flow_diag.entries[n].value=value;
    dust_can_flow_diag.entries[n].aux=aux;
    irq_unlock(key);
}
static uint32_t flow_u32(const uint8_t* p) {
    return (uint32_t)p[0] | ((uint32_t)p[1]<<8) |
        ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
}
void dust_can_flow_image(const uint8_t* data,unsigned bytes,unsigned offset) {
    static uint32_t last_sequence;
    static int present;
    if(offset > bytes || bytes-offset < 16) return;
    const uint8_t* f=data+offset;
    unsigned count=f[8] | ((unsigned)f[9]<<8);
    if(count > (bytes-offset-16)/24) return;
    int found=0;
    for(unsigned n=0;n<count;++n) {
        const uint8_t* v=f+16+n*24;
        if(flow_u32(v)!=0x13) continue;
        uint32_t seq=flow_u32(v+4);
        if(!present || seq!=last_sequence)
            dust_can_flow_event(107,seq,flow_u32(data+24));
        last_sequence=seq; found=1;
    }
    if(present && !found) dust_can_flow_event(108,last_sequence,flow_u32(data+24));
    present=found;
}
#endif
