/* SPDX-License-Identifier: Apache-2.0 */
#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#if defined(CONFIG_DUST_ECAT_ESM_DIAG)
void dust_esm_event(uint32_t event, uint32_t value, uint32_t aux);
void dust_can_flow_event(uint32_t event, uint32_t value, uint32_t aux);
void dust_can_flow_image(const uint8_t* data, unsigned bytes, unsigned offset);
#else
static inline void dust_can_flow_event(uint32_t e,uint32_t v,uint32_t a) {(void)e;(void)v;(void)a;}
static inline void dust_can_flow_image(const uint8_t* p,unsigned n,unsigned o) {(void)p;(void)n;(void)o;}
static inline void dust_esm_event(uint32_t e, uint32_t v, uint32_t a) {(void)e;(void)v;(void)a;}
#endif
#ifdef __cplusplus
}
#endif
